AngularJS + Bootstrap3 导航菜单
=============================

+ AngularJS + Bootstrap3 导航菜单: http://blog.fens.me/bootstrap-angularjs-navbar/
+ Bootstrap3多级导航菜单 http://blog.fens.me/bootstrap-multilevel-navbar/

## 安装

```{bash}
git clone https://github.com/bsspirit/angular-navbar.git
cd angular-navbar
bower install
anywhere
```

## 文件说明

+ page1.html 纯Bootstrap3的实现
+ page2.html Angularjs + Bootstrap3的实现
+ page3.html 静态多级菜单的实现
+ page4.html 动态多级菜单的实现

## License

MIT
